"""Install the provided service after the application upgrade; run with sudo."""
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

if not hasattr(os,'geteuid') or os.geteuid()!=0:
    raise SystemExit('请用 sudo 执行此脚本，以配置开机启动')
root=Path('/home/admin/live-monitor').resolve(strict=True)
unit=Path(__file__).resolve().parent/'tingbo-monitor.service'
dest=Path('/etc/systemd/system/tingbo-monitor.service')
if dest.exists() and 'WorkingDirectory=/home/admin/live-monitor' not in dest.read_text():
    raise SystemExit('存在同名且不属于本项目的服务，停止安装')
subprocess.run(['systemctl','stop','tingbo-monitor.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit(): continue
    try:
        args=(entry/'cmdline').read_bytes().split(b'\0')
        if len(args)>1 and args[1].decode(errors='replace') in ('server.py',str(root/'server.py')) and (entry/'cwd').resolve(strict=True)==root:
            os.kill(int(entry.name),signal.SIGTERM)
    except (OSError,ValueError): pass
time.sleep(2)
shutil.copy2(unit,dest)
subprocess.run(['systemctl','daemon-reload'],check=True)
subprocess.run(['systemctl','enable','--now','tingbo-monitor.service'],check=True)
time.sleep(1)
subprocess.run(['systemctl','is-active','tingbo-monitor.service'],check=True)
print('服务已安装并启动；异常退出会尝试恢复，重启后监控任务需手动开始，避免自动产生模型费用。')
