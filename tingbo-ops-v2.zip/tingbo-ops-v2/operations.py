"""Product/activity snapshots and deterministic, evidence-based speech checks."""
import json
import re
import uuid
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

FIELDS = {
 'product': ['model','aliases','washing_capacity','drying_capacity','energy_level','washing_ratio','dimensions','drying_type','features','selling_points','proof','service_policy','source','verified_by'],
 'activity': ['starts_at','ends_at','applies_to','final_price','coupon_rules','deposit_rules','balance_rules','refund_rules','subsidy_rules','install_rules','source','verified_by']
}

def initialize(c):
    c.executescript('''CREATE TABLE IF NOT EXISTS knowledge(id TEXT PRIMARY KEY,kind TEXT,name TEXT,version INTEGER,data TEXT,updated TEXT,archived INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS knowledge_versions(id TEXT,version INTEGER,snapshot TEXT,PRIMARY KEY(id,version));
    CREATE TABLE IF NOT EXISTS metrics(name TEXT PRIMARY KEY,count INTEGER,last_at TEXT,last_error TEXT);
    CREATE TABLE IF NOT EXISTS audio_jobs(id TEXT PRIMARY KEY,task_id TEXT,path TEXT,offset REAL,profile TEXT,status TEXT,attempts INTEGER DEFAULT 0,message TEXT DEFAULT '',created TEXT,ready INTEGER DEFAULT 1);''')
    for table, fields in {
      'tasks': [('profile',"TEXT DEFAULT '{}'"),('last_audio','TEXT'),('last_transcript','TEXT'),('last_analysis','TEXT'),('gap_count','INTEGER DEFAULT 0'),('reconnects','INTEGER DEFAULT 0')],
      'segments': [('profile',"TEXT DEFAULT '{}'"),('analysis_status',"TEXT DEFAULT 'legacy'"),('analysis_message',"TEXT DEFAULT ''"),('audio_job','TEXT')]
    }.items():
        names={r['name'] for r in c.execute('PRAGMA table_info('+table+')')}
        for key, definition in fields:
            if key not in names: c.execute(f'ALTER TABLE {table} ADD COLUMN {key} {definition}')
    c.execute('CREATE UNIQUE INDEX IF NOT EXISTS unique_audio_segment ON segments(audio_job) WHERE audio_job IS NOT NULL')
    c.execute("UPDATE audio_jobs SET status='paused',ready=0,message='服务重启，待手动恢复' WHERE status IN ('pending','working','retry')")
    c.execute("UPDATE segments SET analysis_status='paused',analysis_message='服务重启，待手动重试分析' WHERE analysis_status IN ('pending','working')")

def serialize(row):
    obj=dict(row)
    obj['data']=json.loads(obj['data'])
    return obj

def save_knowledge(c, body, timestamp):
    kind=body.get('kind')
    if kind not in FIELDS: raise ValueError('请选择商品或活动')
    name=str(body.get('name','')).strip()
    data=body.get('data')
    if not name or len(name)>120 or not isinstance(data,dict): raise ValueError('名称或资料格式不正确')
    clean={k:str(data.get(k,'')).strip() for k in FIELDS[kind]}
    if any(len(v)>4000 for v in clean.values()): raise ValueError('单个资料字段不超过4000字')
    clean['confirmed']=data.get('confirmed') is True
    if kind=='product' and not clean['model']: raise ValueError('请填写完整型号')
    if clean['confirmed'] and (not clean['source'] or not clean['verified_by']): raise ValueError('确认资料前，请填写资料来源和核验人')
    if kind=='activity':
        if not clean['starts_at'] or not clean['ends_at']: raise ValueError('活动必须填写生效与截止时间')
        try:
            start=datetime.fromisoformat(clean['starts_at'].replace('Z','+00:00'))
            end=datetime.fromisoformat(clean['ends_at'].replace('Z','+00:00'))
            if start.tzinfo is None or end.tzinfo is None or start>=end: raise ValueError()
        except ValueError: raise ValueError('活动起止时间不正确') from None
    ident=str(body.get('id') or uuid.uuid4().hex)
    if not re.fullmatch(r'[a-f0-9]{32}',ident): raise ValueError('资料编号不正确')
    prior=c.execute('SELECT * FROM knowledge WHERE id=?',(ident,)).fetchone()
    if prior and (prior['kind']!=kind or prior['archived']): raise ValueError('资料不存在或已归档')
    expected=body.get('version')
    if prior and expected!=prior['version']: raise ValueError('资料已被更新，请重新打开后再保存')
    version=prior['version']+1 if prior else 1
    clean['verified_at']=timestamp if clean['confirmed'] else ''
    snapshot={'id':ident,'kind':kind,'name':name,'version':version,'data':clean,'updated':timestamp,'archived':0}
    c.execute('INSERT OR REPLACE INTO knowledge VALUES (?,?,?,?,?,?,0)',(ident,kind,name,version,json.dumps(clean,ensure_ascii=False),timestamp))
    c.execute('INSERT INTO knowledge_versions VALUES (?,?,?)',(ident,version,json.dumps(snapshot,ensure_ascii=False)))
    return snapshot

def make_profile(c, product_id='', activity_id=''):
    result={}
    for kind, ident in [('product',product_id),('activity',activity_id)]:
        if not ident: continue
        row=c.execute('SELECT * FROM knowledge WHERE id=? AND kind=? AND archived=0',(ident,kind)).fetchone()
        if not row: raise ValueError('选择的商品或活动已不可用，请重新选择')
        result[kind]=serialize(row)
    return result

def activity_state(profile, when=None):
    obj=profile.get('activity')
    if not obj: return '未绑定活动'
    data=obj['data']
    instant=datetime.fromtimestamp(when,timezone.utc) if when else datetime.now(timezone.utc)
    start=datetime.fromisoformat(data['starts_at'].replace('Z','+00:00'))
    end=datetime.fromisoformat(data['ends_at'].replace('Z','+00:00'))
    if instant<start: return '尚未生效'
    if instant>end: return '已过期'
    return '生效中'

def normalize_with_map(text):
    # Keep original evidence coordinates while joining typical speech/numeric variants.
    replacements={'百分之百':'100%','百分百':'100%','扣一':'扣1','一百元':'100元'}
    out=[]; positions=[]; i=0
    while i<len(text):
        key=next((k for k in replacements if text.startswith(k,i)),None)
        if key:
            value=replacements[key]
            out.extend(value.casefold()); positions.extend([(i,i+len(key))]*len(value)); i+=len(key)
        else:
            value=text[i].casefold()
            out.extend(value); positions.extend([(i,i+1)]*len(value)); i+=1
    return ''.join(out),positions

def match_words(text, words):
    normalized, positions=normalize_with_map(text)
    hits=[]
    for word in sorted(set(words),key=len,reverse=True):
        needle=normalize_with_map(word)[0]
        if not needle: continue
        offset=0
        while True:
            index=normalized.find(needle,offset)
            if index<0: break
            a,b=positions[index][0],positions[index+len(needle)-1][1]
            offset=index+len(needle)
            # Exclude only these narrow compound-word cases.
            if word=='滚' and text[a:a+2] in ('滚筒',) or word=='滚' and a and text[a-1:a+1]=='翻滚': continue
            if word=='转运' and ('物流转运' in text[max(0,a-2):b] or text[a:b+2]=='转运中心'): continue
            before=text[max(0,a-12):a]
            negated=bool(re.search(r'(不能|不要|不得|不可以|别|禁止|避免|不是|不承诺)[^，。！？；]{0,7}$',before))
            hits.append((a,b,text[a:b],negated))
    return hits

def keyword_checks(text, rules):
    collected=[]
    for rule in rules:
        words=[x.strip() for x in re.split('[,，\n]',rule['words']) if x.strip()]
        for a,b,quote,negated in match_words(text,words):
            found=next((x for x in collected if a<x['_end'] and b>x['_start']),None)
            if found:
                if rule['name'] not in found['tags']: found['tags'].append(rule['name'])
                if rule.get('source') and rule['source'] not in found['references']: found['references'].append(rule['source'])
                if b-a>found['_end']-found['_start']:
                    found['_start'],found['_end'],found['quote']=a,b,quote
                continue
            collected.append({'_start':a,'_end':b,'type':rule['name'],'tags':[rule['name']],
                'quote':quote,'level':'语境待复核' if negated else '需核验',
                'reason':('这句话包含否定或提醒表达，请先检查完整语境；不是确定违规。' if negated else rule.get('context') or '命中关键词，待人工复核'),
                'suggestion':rule['suggestion'],'source':'关键词规则',
                'references':[rule.get('source') or '自定义规则'],'reference':''})
    for item in collected: item.pop('_start'); item.pop('_end')
    return collected

def reference_checks(text, profile, when=None):
    items=[]
    obj=profile.get('product')
    if not obj or not obj['data'].get('confirmed'): return items
    data=obj['data']; numeral={'一':'1','二':'2','三':'3','四':'4','五':'5'}
    expected=re.search(r'([一二三四五1-5])级',data.get('energy_level','')) or re.fullmatch(r'([一二三四五1-5])',data.get('energy_level','').strip())
    if expected:
        actual=numeral.get(expected.group(1),expected.group(1))
        for hit in re.finditer(r'[一二三四五1-5]级能效',text):
            before=text[max(0,hit.start()-8):hit.start()]
            if re.search(r'(不是|不属于|不能|不要|其他|别的|那款)[^，。]{0,4}$',before): continue
            spoken=numeral.get(hit.group()[0],hit.group()[0])
            if spoken!=actual:
                items.append({'type':'商品资料对照','tags':['商品资料对照'],'quote':hit.group(),'level':'资料不一致待核验',
                    'reason':'当前绑定型号的已确认资料记录为'+data['energy_level']+'，请核对是否切换商品或转写有误。',
                    'suggestion':'核对当前讲解型号和能效标识，再按该型号的实际等级说明。',
                    'source':'商品资料对照','reference':obj['name']+' v'+str(obj['version'])+' / 能效等级 / '+data['source']})
    return items

def merge_findings(findings):
    result=[]
    for item in findings:
        prior=next((i for i in result if i.get('quote')==item.get('quote')),None)
        if prior:
            prior['tags']=list(dict.fromkeys(prior.get('tags',[prior['type']])+item.get('tags',[item['type']])))
            if item.get('reference'):
                references=list(dict.fromkeys([r for r in [prior.get('reference',''),item['reference']] if r]))
                prior['reference']='；'.join(references)
            if item.get('source')=='商品资料对照':
                prior['reason']=item['reason'];prior['suggestion']=item['suggestion'];prior['level']=item['level'];prior['source']='规则 + 商品资料对照'
            if item.get('source')=='AI 待复核':
                prior['reason']=item['reason']; prior['suggestion']=item['suggestion']; prior['source']='规则 + AI 待复核'
        else: result.append(item)
    return result
