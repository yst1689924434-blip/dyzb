"""Run from the extracted update folder on the user's existing Linux server."""
import os
import shutil
import signal
import socket
import sqlite3
import subprocess
import time
from datetime import datetime
from pathlib import Path
from urllib.request import urlopen
import json

source = Path(__file__).resolve().parent
target = Path('/home/admin/live-monitor').resolve(strict=True)
if not (target / 'server.py').is_file() or not (target / '.env').is_file():
    raise SystemExit('未找到现有项目或配置，停止升级，请核对目录')
python = target / '.venv/bin/python'
if not python.exists():
    raise SystemExit('未找到项目虚拟环境，停止升级')
files = ['server.py', 'operations.py', 'attachment_rules.json', 'web/index.html', 'web/app.js', 'web/operations.js', 'web/style.css']
for name in files:
    if not (source / name).is_file():
        raise SystemExit('升级包不完整：' + name)
compile((source / 'server.py').read_text(encoding='utf-8'), 'server.py', 'exec')
compile((source / 'operations.py').read_text(encoding='utf-8'), 'operations.py', 'exec')
if shutil.which('systemctl') and subprocess.run(['systemctl','is-active','--quiet','tingbo-monitor.service']).returncode==0:
    raise SystemExit('本项目已有服务管理，请先执行 sudo systemctl stop tingbo-monitor.service 再升级')
if len(json.loads((source / 'attachment_rules.json').read_text(encoding='utf-8'))) != 10:
    raise SystemExit('附件词表格式异常，停止升级')

owners = []
for entry in Path('/proc').iterdir():
    if not entry.name.isdigit():
        continue
    try:
        args = (entry / 'cmdline').read_bytes().split(b'\0')
        cwd = (entry / 'cwd').resolve(strict=True)
        if len(args) > 1 and args[1].decode(errors='replace') in ('server.py', str(target / 'server.py')) and cwd == target:
            owners.append(int(entry.name))
    except (OSError, ValueError):
        pass
if not owners:
    with socket.socket() as sock:
        sock.settimeout(2)
        if sock.connect_ex(('127.0.0.1', 8787)) == 0:
            raise SystemExit('8787端口被其他进程占用，停止升级，请先确认进程')

backup = target / 'backups' / ('ops-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
backup.mkdir(parents=True, exist_ok=False)
backup.chmod(0o700)
for name in files:
    previous = target / name
    if previous.exists():
        dest = backup / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(previous, dest)
# A consistent database backup also preserves existing custom rules and notes.
database = target / 'data/monitor.db'
if database.exists():
    old = sqlite3.connect(database, timeout=15)
    saved = sqlite3.connect(backup / 'monitor.db')
    try:
        old.backup(saved)
    finally:
        saved.close(); old.close()
    (backup / 'monitor.db').chmod(0o600)
for pid in owners:
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
for _ in range(40):
    with socket.socket() as sock:
        sock.settimeout(.2)
        if sock.connect_ex(('127.0.0.1', 8787)) != 0:
            break
    time.sleep(.25)
else:
    raise SystemExit('原服务未停止，未替换代码。请检查后重试；备份已保存')
for name in files:
    dest = target / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source / name, dest)
    dest.chmod(0o644)
env = dict(os.environ)
env['PATH'] = str(python.parent) + os.pathsep + env.get('PATH', '')
with (target / 'server.log').open('ab') as log:
    proc = subprocess.Popen([str(python), 'server.py'], cwd=target, env=env,
        stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
for _ in range(30):
    if proc.poll() is not None:
        raise SystemExit('启动失败，请查看server.log。旧代码与数据库备份：' + str(backup))
    try:
        with urlopen('http://127.0.0.1:8787/', timeout=1) as response:
            if response.status == 200:
                print('升级成功，网站响应200。请刷新网页并重新登录。')
                print('运营版已启用：商品资料、活动版本、运行状态、独立转写分析和提示去重。')
                print('备份目录：' + str(backup))
                break
    except OSError:
        pass
    time.sleep(.3)
else:
    raise SystemExit('未确认网站响应，请检查server.log。备份：' + str(backup))
